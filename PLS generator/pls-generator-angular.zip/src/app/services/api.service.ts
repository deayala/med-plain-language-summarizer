
import { Injectable } from '@angular/core';
import { SummaryResponse } from '../models/summary';

/**
 * ApiService centraliza todas las llamadas al backend.
 * Reemplaza los métodos mock con peticiones HTTP reales (REST).
 * 
 * Puntos de integración sugeridos (acordarlos con backend):
 *  - POST /api/summarize  body: { text: string } -> SummaryResponse
 *  - GET  /api/history     -> string[]
 *  - GET  /api/metrics/:id -> métricas detalladas
 */
@Injectable()
export class ApiService {

  async mockGenerate(text: string): Promise<SummaryResponse>{
    // === PLACEHOLDER ===
    // Simulación simple: acorta el texto y baja complejidad léxica.
    const summary = text
      .replace(/\s+/g,' ')
      .split('.')
      .slice(0,4)
      .map(s => s.trim())
      .filter(Boolean)
      .map(s => s.replace(/\b(utilizar|adicionalmente|respecto a|debido a)\b/gi, 'usar'))
      .join('. ') + '.';

    // Guardar en historial del navegador (para el panel izquierdo)
    try {
      const saved = JSON.parse(localStorage.getItem('pls_history') || '[]');
      saved.unshift(summary.slice(0,120));
      localStorage.setItem('pls_history', JSON.stringify(saved.slice(0,20)));
    } catch {}

    return {
      summary,
      metrics: {
        contentPrecision: 82,
        readability: 92,
        gradeLevel: 'Grado 8',
        overallGrade: 'A+'
      }
    };
  }
}
