
import { Component, signal } from '@angular/core';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { UploadComponent } from './components/upload/upload.component';
import { SummaryComponent } from './components/summary/summary.component';
import { MetricsComponent } from './components/metrics/metrics.component';
import { ApiService } from './services/api.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [SidebarComponent, UploadComponent, SummaryComponent, MetricsComponent],
  providers: [ApiService],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // Signals to share across components (simple state store)
  originalText = signal<string>('');
  summaryText = signal<string>('');
  // Quality metrics (mocked initially)
  contentPrecision = signal<number>(82); // (%)
  readabilityScore = signal<number>(92); // (%)
  gradeLevel = signal<string>('Grado 8');
  overallGrade = signal<string>('A+');

  constructor(private api: ApiService){}

  handleGenerate = async () => {
    // When user clicks "Generar Resumen" in the upload component
    const input = this.originalText();
    if(!input?.trim()) return;
    // TODO: Replace with real API call: this.api.generateSummary(input)
    const res = await this.api.mockGenerate(input);
    this.summaryText.set(res.summary);
    this.contentPrecision.set(res.metrics.contentPrecision);
    this.readabilityScore.set(res.metrics.readability);
    this.gradeLevel.set(res.metrics.gradeLevel);
    this.overallGrade.set(res.metrics.overallGrade);
  }
}
