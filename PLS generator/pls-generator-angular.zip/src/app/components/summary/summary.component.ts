
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-summary',
  standalone: true,
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent{
  @Input() title = '';
  @Input() text = '';
  @Input() isSummary = false;

  copy(){
    navigator.clipboard.writeText(this.text || '');
  }

  download(){
    const blob = new Blob([this.text || ''], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = this.isSummary ? 'resumen_pls.docx' : 'texto_original.txt'; // Placeholder .docx
    a.click();
    URL.revokeObjectURL(a.href);
  }
}
