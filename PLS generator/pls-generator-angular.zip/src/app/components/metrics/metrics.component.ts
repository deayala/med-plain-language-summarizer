
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-metrics',
  standalone: true,
  templateUrl: './metrics.component.html',
  styleUrls: ['./metrics.component.css']
})
export class MetricsComponent{
  @Input() metricTitle = '';
  @Input() value = 0;        // 0..100
  @Input() suffix = '%';
  @Input() note = '';
}
