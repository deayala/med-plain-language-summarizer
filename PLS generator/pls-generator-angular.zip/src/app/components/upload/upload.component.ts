
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-upload',
  standalone: true,
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {
  @Input() originalText: string = '';
  @Output() originalTextChange = new EventEmitter<string>();
  @Output() generateClicked = new EventEmitter<void>();

  onFileSelected(event: Event){
    const input = event.target as HTMLInputElement;
    const file = input.files && input.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      this.originalTextChange.emit(String(reader.result || ''));
    };
    reader.readAsText(file, 'utf-8');
  }
}
