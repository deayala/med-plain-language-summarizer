
import { Component, OnInit, signal } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit{
  history = signal<string[]>([]);

  ngOnInit(){
    const saved = localStorage.getItem('pls_history');
    if(saved) this.history.set(JSON.parse(saved));
  }

  selectItem(text: string){
    const event = new CustomEvent('historySelected', { detail: text });
    window.dispatchEvent(event);
  }
}
