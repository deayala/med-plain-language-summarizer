
export interface SummaryResponse{
  summary: string;
  metrics: {
    contentPrecision: number;
    readability: number;
    gradeLevel: string;
    overallGrade: string;
  }
}
